const SysEmail= () => {
    return (
      <section>
          <p>Contenedor SysEmail ACTIVO</p>
      </section>
    );
  };

export default SysEmail;