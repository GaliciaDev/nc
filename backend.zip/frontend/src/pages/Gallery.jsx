const Gallery= () => {
    return (
      <section>
          <p>Contenedor Gallery ACTIVO</p>
      </section>
    );
  };

export default Gallery;