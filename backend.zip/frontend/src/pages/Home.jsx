
import Cover from '../components/Cover.jsx';


const Home= () => {
    return (
      <section>
        <Cover />
      </section>
    );
  };

export default Home;