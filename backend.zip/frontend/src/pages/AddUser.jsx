const AddUser= () => {
    return (
      <section>
          <p>Contenedor AddUser ACTIVO</p>
      </section>
    );
  };

export default AddUser;