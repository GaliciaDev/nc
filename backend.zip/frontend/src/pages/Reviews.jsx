const Reviews= () => {
    return (
      <section>
          <p>Contenedor Reviews ACTIVO</p>
      </section>
    );
  };

export default Reviews;