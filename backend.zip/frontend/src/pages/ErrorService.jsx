const ErrorService= () => {
    return (
      <section>
          <p>Contenedor ErrorService ACTIVO</p>
      </section>
    );
  };

export default ErrorService;