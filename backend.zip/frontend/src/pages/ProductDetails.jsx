const ProductDetails= () => {
    return (
      <section>
          <p>Contenedor ProductDetails ACTIVO</p>
      </section>
    );
  };

export default ProductDetails;