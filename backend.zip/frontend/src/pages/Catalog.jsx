const Catalog= () => {
    return (
      <section>
          <p>Contenedor Catalog ACTIVO</p>
      </section>
    );
  };

export default Catalog;