const AboutExtend= () => {
    return (
      <section>
          <p>Contenedor AboutExtend ACTIVO</p>
      </section>
    );
  };

export default AboutExtend;