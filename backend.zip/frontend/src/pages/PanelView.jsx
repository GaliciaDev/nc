
const PanelView= () => {
    return (
      <section>
          <p>Contenedor PanelView ACTIVO</p>
      </section>
    );
  };

export default PanelView;