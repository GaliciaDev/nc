const Footer = () => {
    return (
        <footer >
            <p>Corrige</p>
        </footer>
    );
    }

export default Footer;

