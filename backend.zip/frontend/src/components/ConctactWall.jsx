const ContactWall = () => {
    return (
        <div>
        <h1>ContactWall</h1>
        </div>
    );
    }

export default ContactWall;