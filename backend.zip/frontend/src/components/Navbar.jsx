import React from 'react';



const Navbar = () => {
  return (
    <section>
        <p>Contenedor Nav ACTIVO</p>
    </section>
  );
};

export default Navbar;





