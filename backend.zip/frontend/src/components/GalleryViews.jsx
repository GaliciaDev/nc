const GalleryViews = () => {
    return (
        <div>
        <h1>GalleryViews</h1>
        </div>
    );
    }

export default GalleryViews;