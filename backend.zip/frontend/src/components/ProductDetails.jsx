const ProductDetails = () => {
  return (
    <div>
      <h1>Product Details</h1>
    </div>
  );
}

export default ProductDetails;