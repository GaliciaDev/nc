const SocialWall = () => {
    <div>
        <h1>SocialWall</h1>
    </div>
}

export default SocialWall;