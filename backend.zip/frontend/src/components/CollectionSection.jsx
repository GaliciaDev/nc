const CollectionSection = () => {
    
    return (
        <section>
        
        </section>
    );
    }

export default CollectionSection;