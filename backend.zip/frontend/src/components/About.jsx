const About = () => {
    return (
        <div>
        <p>About Funcionando</p>
        </div>
    );
    }
export default About;