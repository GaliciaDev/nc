const AddEvent = () => {
    return (
        <div>
            <h1>Add Event</h1>
        </div>
    )
}


export default AddEvent;
