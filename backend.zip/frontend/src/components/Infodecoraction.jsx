const Infodecoraction = () => {
    <div>
        <h1>Infodecoraction</h1>
    </div>
}

export default Infodecoraction;