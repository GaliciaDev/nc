const ContactEdit = () => {

    return (
        <div>
            <h1>Contact Edit</h1>
        </div>
    );
}

export default ContactEdit;