const AllProducts = () => {
        
    return (
        <div>
        <p>AllProducts Funcionando</p>
        </div>
    );
    }

export default AllProducts;