const SwiperWall = () => {
    <div>
        <h1>SwiperWall</h1>
    </div>
}

export default SwiperWall;