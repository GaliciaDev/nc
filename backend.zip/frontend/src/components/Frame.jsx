const Frame = () => {
    return (
        <div>
        <h2>Frame</h2>
        </div>
    );
    }

export default Frame;