const Carousel = () => {
    return (
        <div>
        <p>Carousel Funcionando</p>
        
        </div>
    );
    }

export default Carousel;